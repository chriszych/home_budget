<?php
	session_start();
	if(isset($_SESSION['logged_id'])){
		header('Location: main.php');
	}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet"
  integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
  <link rel="stylesheet" href="./style.css">
  <script src="https://kit.fontawesome.com/f7c473a27a.js" crossorigin="anonymous"></script>
  <title>Budżet domowy online</title>
</head>

<body>

  <nav id="navBar">
    <!-- navBar -->
    <div class="navbar navbar-expand-lg bg-body-tertiary rounded">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#logNavbar" aria-controls="logNavbar" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
  
        <div class="collapse navbar-collapse d-lg-flex" id="logNavbar">
          <a href="./index.php"><i class="fa-solid fa-house-chimney" style="color: #2861c3;"></i></a>
          <h1><a class="navbar-brand col-lg-3 me-0" href="./index.php">&nbsp;Budżet online</a></h1>
          <ul class="navbar-nav col-lg-9 justify-content-lg-end">
            <li class="nav-item">
              <a class="btn btn-lg btn-primary m-1" href="./login.php">Logowanie</a>
            </li>
            <li class="nav-item">
              <a class="btn btn-lg btn-outline-primary m-1" href="./register.php">Rejestracja</a>
            </li>
          </ul>
        </div>
      </div>
    </div>

  </nav>

  
  <!-- welcomePage -->
  <main id="welcomePage">

    <div class="container col-xxl-8 px-4 py-5">
      <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
        <div class="col-10 col-sm-8 col-lg-6">
          <img src="./pics/05main.jpg" class="d-block mx-lg-auto img-fluid" alt="Bootstrap Themes" width="450" height="300" loading="lazy">
        </div>
        <div class="col-lg-6 text-center">
          <p class="lead display-6 fw-bold text-center">Odzyskaj kontrolę nad domowymi finansami!</p>
          <br><br>
          <p class="lead text-center">Nad domowymi finansami da się i trzeba zapanować. Zarządzanie domowymi finansami daje spokój ducha oraz wymierne korzyści. <br>Nigdy więcej sytuacji, gdy pięniądze się rozchodzą a kwota na Twoim koncie ciągle maleje. <br><br>Aplikacja została opracowana po to aby skatalogować oraz zsumować domowe przychody i wydatki. <br>Zrób to razem z nami za pomocą łatwego i intuicyjnego narzędzia online, które jest bezpieczne i zawsze dostępne dla Ciebie, na Twoim komputerze, laptopie, tablecie czy telefonie. <br><br>Zaczynamy? <br><br></p>
          <div class="d-grid gap-2 d-md-flex justify-content-md-center">
            <a href="./login.php" class="w-100 mb-2 btn btn-lg rounded-3 btn-primary my-1 mb-5" role="button">Zaloguj się!</a>
            <a href="./register.php" class="w-100 mb-2 btn btn-lg rounded-3 btn-outline-secondary my-1 mb-5" role="button">Zarejestruj się!</a>
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer id="footer">

    <div class="footer container ">
      <div class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <div class="col-md-4 d-flex align-items-center">
          <span class="mb-3 mb-md-0 text-body-secondary">Budżet online &#169; 2024</span>
        </div>
    
        <ul class="socials nav col-md-4 justify-content-end list-unstyled d-flex ">
          
          <li class="ms-3"><a href="#" class="text-body-secondary"><i class="fa-brands fa-facebook"></i></a></li>
          <li class="ms-3"><a href="#" class="text-body-secondary"><i class="fa-brands fa-linkedin"></i></a></li>
          <li class="ms-3"><a href="#" class="text-body-secondary"><i class="fa-brands fa-github"></i></a></li>
          
        </ul>
      </div>
    </div>


  </footer>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>

</html>