<?php
	
	return ['host' => 'localhost', 
			'user' => 'root',
			'password' => '',
			'database' => 'home_budget'
			];
